package Test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Calendar;
import java.util.Date;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import Appointment.Appointment;
import Appointment.AppointmentService;

class AppointmentServiceTest {

    // Helper to create a future date
    private Date getFutureDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 10); // 10 days from today
        return cal.getTime();
    }

    // Helper to create another future date for updates
    private Date getAnotherFutureDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 20);
        return cal.getTime();
    }

    @Test
    @DisplayName("Should add a new appointment")
    void testAddAppointment() {
        AppointmentService service = new AppointmentService();
        service.addAppointment(getFutureDate(), "Test Description");

        // There should be one appointment with a non-null ID
        Appointment a = service.getAppointment("0");
        assertNotNull(a);
        assertEquals("Test Description", a.getAppointmentDesc());
    }

    @Test
    @DisplayName("Should update the appointment description")
    void testUpdateAppointmentDesc() {
        AppointmentService service = new AppointmentService();
        service.addAppointment(getFutureDate(), "Old Description");

        Appointment a = service.getAppointment("1"); // next ID
        assertNotNull(a);

        service.updateAppointmentDesc("New Description", a.getAppointmentID());

        assertEquals("New Description", a.getAppointmentDesc());
    }

    @Test
    @DisplayName("Should update the appointment date")
    void testUpdateAppointmentDate() {
        AppointmentService service = new AppointmentService();
        service.addAppointment(getFutureDate(), "Some Description");

        Appointment a = service.getAppointment("2"); // next ID
        assertNotNull(a);

        Date newDate = getAnotherFutureDate();
        service.updateAppointmentDate(a.getAppointmentID(), newDate);

        assertEquals(newDate, a.getAppointmentDate());
    }

    @Test
    @DisplayName("Should delete the appointment")
    void testDeleteAppointment() {
        AppointmentService service = new AppointmentService();
        service.addAppointment(getFutureDate(), "To be deleted");

        Appointment a = service.getAppointment("3"); // next ID
        assertNotNull(a);

        service.deleteAppointment(a.getAppointmentID());

        assertNull(service.getAppointment(a.getAppointmentID()));
    }
}
