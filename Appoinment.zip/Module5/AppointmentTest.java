package Test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Calendar;
import java.util.Date;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import Appointment.Appointment;

class AppointmentTest {

    // Helper method to create a valid future date
    private Date getFutureDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 10); // 10 days in the future
        return cal.getTime();
    }

    // Helper method to create a past date
    private Date getPastDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -10); // 10 days in the past
        return cal.getTime();
    }

    @Test
    @DisplayName("Appointment ID must be 10 characters or fewer")
    void testAppointmentIDLengthLimit() {
        Appointment appointment = new Appointment(getFutureDate(), "Test");
        assertTrue(appointment.getAppointmentID().length() <= 10, "Appointment ID exceeded 10 characters.");
    }

    @Test
    @DisplayName("Appointment description must be 50 characters or fewer")
    void testDescriptionLengthLimit() {
        String longDescription = "This is a very long appointment description that exceeds 50 characters.";
        Appointment appointment = new Appointment(getFutureDate(), longDescription);
        assertTrue(appointment.getAppointmentDesc().length() <= 50, "Appointment description exceeded 50 characters.");
    }

    @Test
    @DisplayName("Appointment date cannot be in the past")
    void testDateCannotBeInPast() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(getPastDate(), "Test");
        }, "Expected exception for past date not thrown.");
    }

    @Test
    @DisplayName("Appointment date should not be null")
    void testDateNotNull() {
        Appointment appointment = new Appointment(null, "Valid description");
        assertNotNull(appointment.getAppointmentDate(), "Appointment date should not be null.");
    }

    @Test
    @DisplayName("Appointment description should not be null")
    void testDescriptionNotNull() {
        Appointment appointment = new Appointment(getFutureDate(), null);
        assertNotNull(appointment.getAppointmentDesc(), "Appointment description should not be null.");
    }

    @Test
    @DisplayName("Appointment ID should not be null")
    void testIDNotNull() {
        Appointment appointment = new Appointment(getFutureDate(), "Test");
        assertNotNull(appointment.getAppointmentID(), "Appointment ID should not be null.");
    }

    @Test
    @DisplayName("Appointment ID should not be updatable")
    void testIDImmutability() {
        Appointment appointment = new Appointment(getFutureDate(), "Test");
        // No setter exists — just checking that ID is final and accessible
        String idBefore = appointment.getAppointmentID();
        String idAfter = appointment.getAppointmentID();
        assertEquals(idBefore, idAfter, "Appointment ID changed unexpectedly.");
    }
}