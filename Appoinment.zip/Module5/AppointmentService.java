package Appointment;

import java.util.ArrayList;
import java.util.Date;

public class AppointmentService {
    // Internal list of appointments
    private final ArrayList<Appointment> appointmentList = new ArrayList<>();

    // Add a new appointment if ID is unique
    public void addAppointment(Date appointmentDate, String appointmentDesc) {
        Appointment newAppointment = new Appointment(appointmentDate, appointmentDesc);
        String newID = newAppointment.getAppointmentID();

        // Ensure uniqueness
        if (findAppointmentById(newID) != null) {
            throw new IllegalArgumentException("Appointment ID must be unique.");
        }

        appointmentList.add(newAppointment);
    }

    // Delete an appointment by ID
    public void deleteAppointment(String appointmentID) {
        Appointment toDelete = findAppointmentById(appointmentID);
        if (toDelete != null) {
            appointmentList.remove(toDelete);
        } else {
            System.out.println("Appointment ID: " + appointmentID + " not found.");
        }
    }

    // Update the appointment date
    public void updateAppointmentDate(String appointmentID, Date updatedDate) {
        Appointment toUpdate = findAppointmentById(appointmentID);
        if (toUpdate != null) {
            toUpdate.setAppointmentDate(updatedDate);
        } else {
            System.out.println("Appointment ID: " + appointmentID + " not found.");
        }
    }

    // Update the appointment description
    public void updateAppointmentDesc(String appointmentID, String updatedDesc) {
        Appointment toUpdate = findAppointmentById(appointmentID);
        if (toUpdate != null) {
            toUpdate.setAppointmentDesc(updatedDesc);
        } else {
            System.out.println("Appointment ID: " + appointmentID + " not found.");
        }
    }

    // Get an appointment by ID
    public Appointment getAppointment(String appointmentID) {
        return findAppointmentById(appointmentID);
    }

    // Display all appointments (for debugging)
    public void displayAppointmentList() {
        for (Appointment a : appointmentList) {
            System.out.println("\tAppointment ID: " + a.getAppointmentID());
            System.out.println("\tAppointment Date: " + a.getAppointmentDate());
            System.out.println("\tAppointment Description: " + a.getAppointmentDesc());
        }
    }

    // Private helper to find appointment by ID
    private Appointment findAppointmentById(String appointmentID) {
        for (Appointment a : appointmentList) {
            if (a.getAppointmentID().equals(appointmentID)) {
                return a;
            }
        }
        return null;
    }
}