package Appointment;

import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.atomic.AtomicLong;

public class Appointment {
    private final String appointmentID;
    private Date appointmentDate;
    private String appointmentDesc;
    private static final AtomicLong idGenerator = new AtomicLong();

    // Constructor
    public Appointment(Date appointmentDate, String appointmentDesc) {
        // Generate unique ID
        String id = String.valueOf(idGenerator.getAndIncrement());
        if (id.length() > 10) {
            throw new IllegalArgumentException("Appointment ID cannot exceed 10 characters.");
        }
        this.appointmentID = id;

        // Validate and set appointment date
        if (appointmentDate == null) {
            this.appointmentDate = getDefaultDate();
        } else if (appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Appointment date cannot be in the past.");
        } else {
            this.appointmentDate = appointmentDate;
        }

        // Validate and set description
        if (appointmentDesc == null || appointmentDesc.trim().isEmpty()) {
            this.appointmentDesc = "NULL";
        } else if (appointmentDesc.length() > 50) {
            this.appointmentDesc = appointmentDesc.substring(0, 50);
        } else {
            this.appointmentDesc = appointmentDesc;
        }
    }

    // Getters
    public String getAppointmentID() {
        return appointmentID;
    }

    public Date getAppointmentDate() {
        return appointmentDate;
    }

    public String getAppointmentDesc() {
        return appointmentDesc;
    }

    // Setters
    public void setAppointmentDate(Date appointmentDate) {
        if (appointmentDate == null) {
            this.appointmentDate = getDefaultDate();
        } else if (appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Appointment date cannot be in the past.");
        } else {
            this.appointmentDate = appointmentDate;
        }
    }

    public void setAppointmentDesc(String appointmentDesc) {
        if (appointmentDesc == null || appointmentDesc.trim().isEmpty()) {
            this.appointmentDesc = "NULL";
        } else if (appointmentDesc.length() > 50) {
            this.appointmentDesc = appointmentDesc.substring(0, 50);
        } else {
            this.appointmentDesc = appointmentDesc;
        }
    }

    // Helper method for default date
    private Date getDefaultDate() {
        Calendar cal = Calendar.getInstance();
        cal.set(2022, Calendar.JANUARY, 1, 0, 0, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTime();
    }
}