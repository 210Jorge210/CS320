import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;



class ContactTest {
	

	@Test
	void testContactCalss() {
		Contact newContact = new Contact("999", "Alan", "Ryan", "2105556789", 
				"210 Countdown, TX 78221");
		assertTrue(newContact.getFirstName().equals("Alan"));
		assertTrue(newContact.getLastName().equals("Ryan"));
		assertTrue(newContact.getId().equals("999"));
		assertTrue(newContact.getPhoneNumber().equals("2105556789"));
		assertTrue(newContact.getAddress().equals("210 Countdown, TX 78221"));
	}
	// testing long ID lenght
	@Test
	void testContactClassIdTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("999999999999999999", "Alan", "Ryan", "2105556789", 
					"210 Countdown, TX 78221");
		});
	}
	// testing if null ID
	@Test
	void testContactClassIdNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(null, "Alan", "Ryan", "2105556789", 
					"210 Countdown, TX 78221");
		});
	}
	// testing  first name lenght 
	@Test
	void testContactClassFirstNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("999", "Alannnnnnnnnnnn", "Ryan", "2105556789", 
					"210 Countdown, TX 78221");
		});
	}
	// testing if null first name
	@Test
	void testContactClassFirstNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("999", null , "Ryan", "2105556789", 
					"210 Countdown, TX 78221");
		});
	}
	// testing last name length 
	@Test
	void testContactClassLastNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("999", "Alan", "Ryannnnnnnnnnnnnnn", "2105556789", 
					"210 Countdown, TX 78221");
		});
	}
	// testing if null last name
	@Test
	void testContactClassLastNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("999", "Alan", null, "2105556789", 
					"210 Countdown, TX 78221");
		});
	}
	// testing if not exactly 10 characters
	@Test
	void testContactClassPhoneNot10() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("999", "Alan", "Ryan", "21055567", 
					"210 Countdown, TX 78221");
		});
	}
	// testing if null phone
	@Test
	void testContactCalssPhoneNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("999", "Alan", "Ryan", null, 
					"210 Countdown, TX 78221");
		});
	}
	// testing address length 
	@Test
	void testContactClassAddressTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("999", "Alan", "Ryan", "2105556789", 
					"210 Countdown, TX 78221 210 Countdowncity yea boi less go");
		});
	}
	// testing if null address
	@Test
	void testContactClassAddressnull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("999", "Alan", "Ryan", "2105556789", 
					null);
		});
	}
	
	@Test
	void testContactClassSetFirstName() {
		Contact newContact = new Contact("210", "Ray", "Roger", "2105556789", "address new");
		newContact.setFirstName("Rodger");
		assertTrue(newContact.getFirstName().equals("Rodger"));
	}
	@Test
	void testContactClassSetFirstNameTooLong() {
		Contact newContact = new Contact("210", "Ray", "Roger", "2105556789", "address new");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.setFirstName("RodgerTooLong");
		});
	}
	@Test
	void testContactClassSetFirstNameNull() {
		Contact newContact = new Contact("210", "Ray", "Roger", "2105556789", "address new");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.setFirstName(null);
		});
	}

	@Test
	void testContactClassSetLastName() {
		Contact newContact = new Contact("210", "Ray", "Roger", "2105556789", "address new");
		newContact.setLastName("Rodger");
		assertTrue(newContact.getLastName().equals("Rodger"));
	}
	@Test
	void testContactClassSetLastNameTooLong() {
		Contact newContact = new Contact("210", "Ray", "Roger", "2105556789", "ddress new");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.setLastName("RodgerTooLong");
		});
	}
	@Test
	void testContactClassSetLastNameNull() {
		Contact newContact = new Contact("210", "Ray", "Roger", "2105556789", "address new");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.setLastName(null);
		});
	}

	@Test
	void testContactClassSetPhoneNumber() {
		Contact newContact = new Contact("210", "Ray", "Roger", "2105556789", "address new");
		newContact.setPhoneNumber("2105556789");
		assertTrue(newContact.getPhoneNumber().equals("2105556789"));
	}
	@Test
	void testContactClassSetPhoneNumberTooLong() {
		Contact newContact = new Contact("210", "Ray", "Roger", "2105556789", "address new");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.setPhoneNumber("2105556789789979798");
		});
	}
	@Test
	void testContactClassSetPhoneNull() {
		Contact newContact = new Contact("210", "Ray", "Roger", "2105556789", "address new");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.setPhone(null);
		});
	}
	@Test
	void testContactClassSetPhoneNumberTooShort() {
		Contact newContact = new Contact("210", "Ray", "Roger", "2105556789", "address new");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.setPhoneNumber("210555");
		});
	}
	
	@Test
	void testContactClassSetAddress() {
		Contact newContact = new Contact("210", "Ray", "Roger", "2105556789", "address new");
		newContact.setAddress("new address 2");
		assertTrue(newContact.getAddress().equals("address new 2"));
	}
	@Test
	void testContactClassSetAddressTooLong() {
		Contact newContact = new Contact("210", "Ray", "Roger", "2105556789", "address new");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.setAddress("address new 987654321000 too long");
		});
	}
	@Test
	void testContactClassSetAddressNull() {
		Contact newContact = new Contact("845", "Jack", "Jones", "6618886118", "address new");
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			newContact.setAddress(null);
		});
	}
	

}