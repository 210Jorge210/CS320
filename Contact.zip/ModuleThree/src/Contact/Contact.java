package Contact;

public class Contact {
	// variables for the class
	private String contactId;
	private String firstName;
	private String lastName;
	private String phoneNumber;
	private String address;

	
public Contact(String contactId, String firstName, String lastName, String phoneNumber, String address) {
	// requirement check ID
	if (contactId == null || contactId.length() > 10) {
		throw new IllegalArgumentException("ID INvalid");
	}
	//requirement check first name
	if (firstName == null || firstName.length() > 10) {
		throw new IllegalArgumentException("First Name Invalid");
	}
	// requirement check last name 
	if (lastName == null || lastName.length() > 10) {
		throw new IllegalArgumentException("Last Name Invalid");
	}
	// requirement check for phone number 
	if (phoneNumber == null || phoneNumber.length() != 10) {
		throw new IllegalArgumentException("Phone Number Invalid");
	}
	// requirement check for address  
	if (address == null || address.length() > 30) {
		throw new IllegalArgumentException("Invalid Address");
	}
	//
	this.contactId = contactId;
	this.firstName = firstName;
	this.lastName = lastName;
	this.phoneNumber = phoneNumber;
	this.address = address;
}


public String getId() {
	return contactId;
}
public String getFirstName() {
	return firstName;
}
public String getLastName() {
	return lastName;
}
public String getPhoneNumber() {
	return phoneNumber;
}
public String getAddress() {
	return address;
}

public void setFirstName(String fName) {
	if (fName == null || fName.length() > 10) {
		throw new IllegalArgumentException("First Name Invaild");
	}
	this.firstName = fName;
}
public void setLastName(String lName) {
	if (lName == null || lName.length() > 10) {
		throw new IllegalArgumentException("Last Name Invalid");
	}
	this.lastName = lName;
}
public void setPhoneNumber(String newPhoneNumber) {
	if (newPhoneNumber == null || newPhoneNumber.length() != 10) {
		throw new IllegalArgumentException("PhoneNumber Invalid");
	}
	this.phoneNumber = newPhoneNumber;
}
public void setAddress(String newAddress) {
	if (newAddress == null || newAddress.length() > 30) {
		throw new IllegalArgumentException("Address Invalid");
	}
	this.address = newAddress;
}
}