package Appointment;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;
import java.util.Calendar;

public class AppointmentTest {

    private Date futureDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 1);
        return cal.getTime();
    }

    @Test
    void testValidAppointment() {
        Appointment appt = new Appointment("12345", futureDate(), "Dentist visit");
        assertEquals("12345", appt.getAppointmentId());
        assertEquals("Dentist visit", appt.getDescription());
        assertNotNull(appt.getAppointmentDate());
    }

    @Test
    void testInvalidId() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, futureDate(), "Checkup");
        });
    }

    @Test
    void testPastDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -1);
        Date pastDate = cal.getTime();

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", pastDate, "Old meeting");
        });
    }

    @Test
    void testInvalidDescription() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", futureDate(), null);
        });
    }
}
