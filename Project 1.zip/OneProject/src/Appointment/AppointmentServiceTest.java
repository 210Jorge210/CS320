package Appointment;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Calendar;
import java.util.Date;

public class AppointmentServiceTest {

    private Date futureDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 2);
        return cal.getTime();
    }

    @Test
    void testAddAppointment() {
        AppointmentService service = new AppointmentService();
        Appointment appt = new Appointment("A1", futureDate(), "Project meeting");
        service.addAppointment(appt);
        assertEquals(appt, service.getAppointment("A1"));
    }

    @Test
    void testAddDuplicate() {
        AppointmentService service = new AppointmentService();
        Appointment appt1 = new Appointment("A1", futureDate(), "Meeting");
        Appointment appt2 = new Appointment("A1", futureDate(), "Another");

        service.addAppointment(appt1);
        assertThrows(IllegalArgumentException.class, () -> service.addAppointment(appt2));
    }

    @Test
    void testDeleteAppointment() {
        AppointmentService service = new AppointmentService();
        Appointment appt = new Appointment("A2", futureDate(), "Doctor visit");
        service.addAppointment(appt);
        service.deleteAppointment("A2");
        assertNull(service.getAppointment("A2"));
    }

    @Test
    void testDeleteNonexistent() {
        AppointmentService service = new AppointmentService();
        assertThrows(IllegalArgumentException.class, () -> service.deleteAppointment("999"));
    }
}
