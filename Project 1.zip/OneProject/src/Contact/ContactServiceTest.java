package Contact;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {

    @Test
    void testAddContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("123", "Tony", "Parker", "1234567890", "123 Main St");
        service.addContact(contact);
        assertEquals(contact, service.getContact("123"));
    }

    @Test
    void testAddDuplicateContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("123", "Tony", "Parker", "1234567890", "123 Main St");
        service.addContact(contact);
        assertThrows(IllegalArgumentException.class, () -> service.addContact(contact));
    }

    @Test
    void testDeleteContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("123", "Tony", "Parker", "1234567890", "123 Main St");
        service.addContact(contact);
        service.deleteContact("123");
        assertNull(service.getContact("123"));
    }

    @Test
    void testUpdateContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("123", "Tony", "Parker", "1234567890", "123 Main St");
        service.addContact(contact);

        service.updateFirstName("123", "Chris");
        assertEquals("Chris", service.getContact("123").getFirstName());

        service.updateLastName("123", "Paul");
        assertEquals("Paul", service.getContact("123").getLastName());

        service.updatePhone("123", "0987654321");
        assertEquals("0987654321", service.getContact("123").getPhone());

        service.updateAddress("123", "456 Oak Ave");
        assertEquals("456 Oak Ave", service.getContact("123").getAddress());
    }
}
