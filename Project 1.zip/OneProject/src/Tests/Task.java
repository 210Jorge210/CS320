package Tests;

public class Task {

    private final String uniqueID;
    private String fullName;
    private String description;

    // Validation methods
    private boolean validateID(String uniqueID) {
        return uniqueID != null && uniqueID.length() <= 10;
    }

    private boolean validateName(String fullName) {
        return fullName != null && !fullName.isEmpty() && fullName.length() <= 20;
    }

    private boolean validateDescription(String description) {
        return description != null && !description.isEmpty() && description.length() <= 50;
    }

    // Constructor
    public Task(String uniqueID, String fullName, String description) {
        if (!validateID(uniqueID)) {
            throw new IllegalArgumentException("Invalid ID");
        }
        if (!validateName(fullName)) {
            throw new IllegalArgumentException("Invalid name");
        }
        if (!validateDescription(description)) {
            throw new IllegalArgumentException("Invalid description");
        }

        this.uniqueID = uniqueID;
        this.fullName = fullName;
        this.description = description;
    }

    // Getters
    public String getUniqueID() {
        return uniqueID;
    }

    public String getName() {
        return fullName;
    }

    public String getDescription() {
        return description;
    }

    // Setters with validation
    public void setName(String fullName) {
        if (!validateName(fullName)) {
            throw new IllegalArgumentException("Invalid name");
        }
        this.fullName = fullName;
    }

    public void setDescription(String description) {
        if (!validateDescription(description)) {
            throw new IllegalArgumentException("Invalid description");
        }
        this.description = description;
    }
}
