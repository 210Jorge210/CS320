package Tests;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class TaskService {
    
    private int currentIDNum = 0; // pseudo GUID
    
    private static HashMap<String, Task> tasks = new HashMap<>();
    
    // Adds a new task with auto-generated ID and returns the ID
    public String addUniqueTask(String name, String description) {
        String stringID = Integer.toString(currentIDNum);
        Task tempTask = new Task(stringID, name, description);
        tasks.put(stringID, tempTask);
        currentIDNum++;
        return stringID;
    }
    
    // Adds a task with explicit ID, throws if ID already exists
    public void addTaskWithID(String id, String name, String description) {
        if (tasks.containsKey(id)) {
            throw new IllegalArgumentException("Task ID already exists: " + id);
        }
        Task tempTask = new Task(id, name, description);
        tasks.put(id, tempTask);
    }
    
    // Deletes a task by ID; no error if ID not found
    public void deleteTasks(String id) {
        tasks.remove(id);
    }
    
    // Updates a task's name and description; no-op if ID not found
    public void updateTasks(String id, String newName, String newDescription) {
        Task task = tasks.get(id);
        if (task != null) {
            task.setName(newName);
            task.setDescription(newDescription);
        }
    }
    
    // Returns task by ID or null if not found
    public Task getTaskById(String id) {
        return tasks.get(id);
    }
    
    // Returns an unmodifiable map of all tasks
    public Map<String, Task> getAllTasks() {
        return Collections.unmodifiableMap(tasks);
    }
    
    // Clears all tasks - useful for tests
    public void clearAllTasks() {
        tasks.clear();
        currentIDNum = 0;
    }
}
