package Tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import TaskClass.Task;

class TaskTest {

    @Test
    @DisplayName("Valid Task creation")
    void testValidTaskCreation() {
        Task task = new Task("123", "Task Name", "Task description");
        assertEquals("123", task.getUniqueID());
        assertEquals("Task Name", task.getName());
        assertEquals("Task description", task.getDescription());
    }

    @Test
    @DisplayName("Invalid Task ID throws exception")
    void testInvalidID() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Name", "Description");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Name", "Description"); // > 10 chars
        });
    }

    @Test
    @DisplayName("Invalid Name throws exception")
    void testInvalidName() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("123", null, "Description");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("123", "", "Description");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("123", "ThisNameIsWayTooLongForTheRequirement", "Description");
        });
    }

    @Test
    @DisplayName("Invalid Description throws exception")
    void testInvalidDescription() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("123", "Name", null);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("123", "Name", "");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("123", "Name", "D".repeat(51));
        });
    }

    @Test
    @DisplayName("Update with valid data")
    void testUpdateSetters() {
        Task task = new Task("1", "Name", "Description");
        task.setName("New Name");
        task.setDescription("New Description");
        assertEquals("New Name", task.getName());
        assertEquals("New Description", task.getDescription());
    }

    @Test
    @DisplayName("Setters throw exception for invalid data")
    void testSettersInvalidData() {
        Task task = new Task("1", "Name", "Description");
        assertThrows(IllegalArgumentException.class, () -> {
            task.setName(null);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            task.setName("NameThatIsWayTooLongToBeValid");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            task.setDescription(null);
        });
        assertThrows(IllegalArgumentException.class, () -> {
            task.setDescription("");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            task.setDescription("D".repeat(51));
        });
    }
}
