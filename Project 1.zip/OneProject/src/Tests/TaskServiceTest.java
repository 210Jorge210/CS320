package Tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import TaskClass.TaskService;

class TaskServiceTest {

    private TaskService tempTask;

    @AfterEach
    void tearDown() throws Exception {
        tempTask.clearAllTasks();
    }

    @Test
    @DisplayName("Adding unique tasks")
    void testAddUniqueTask() {
        tempTask = new TaskService();

        String fullName = "Tony Parker";
        String description = "This is the description.";

        String taskId = tempTask.addUniqueTask(fullName, description);

        assertNotNull(taskId, "Task ID should not be null");
        assertEquals(fullName, tempTask.getTaskById(taskId).getName());
        assertEquals(description, tempTask.getTaskById(taskId).getDescription());
        assertEquals(1, tempTask.getAllTasks().size());
    }

    @Test
    @DisplayName("Adding duplicate task ID should throw exception")
    void testAddDuplicateID() {
        tempTask = new TaskService();

        String fullName = "Tony Parker";
        String description = "This is the description.";

        String taskId = tempTask.addUniqueTask(fullName, description);

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            tempTask.addTaskWithID(taskId, "Different Name", "Different Description");
        });

        assertTrue(exception.getMessage().contains("already exists"));
    }

    @Test
    @DisplayName("Deleting task by valid ID")
    void testDeleteTask() {
        tempTask = new TaskService();

        String id1 = tempTask.addUniqueTask("Task One", "Description One");
        String id2 = tempTask.addUniqueTask("Task Two", "Description Two");
        String id3 = tempTask.addUniqueTask("Task Three", "Description Three");

        assertEquals(3, tempTask.getAllTasks().size());

        tempTask.deleteTasks(id2);

        assertEquals(2, tempTask.getAllTasks().size());
        assertNull(tempTask.getTaskById(id2));
    }

    @Test
    @DisplayName("Deleting task by invalid ID does nothing")
    void testDeleteInvalidTask() {
        tempTask = new TaskService();

        tempTask.addUniqueTask("Task One", "Description One");
        tempTask.deleteTasks("nonexistentID");

        assertEquals(1, tempTask.getAllTasks().size());
    }

    @Test
    @DisplayName("Update task with valid ID and valid data")
    void testUpdateTaskValid() {
        tempTask = new TaskService();

        String taskId = tempTask.addUniqueTask("Original Name", "Original Description");

        tempTask.updateTasks(taskId, "Updated Name", "Updated Description");

        assertEquals("Updated Name", tempTask.getTaskById(taskId).getName());
        assertEquals("Updated Description", tempTask.getTaskById(taskId).getDescription());
    }

    @Test
    @DisplayName("Update task with invalid ID does nothing")
    void testUpdateTaskInvalidID() {
        tempTask = new TaskService();

        String taskId = tempTask.addUniqueTask("Original Name", "Original Description");

        tempTask.updateTasks("badID", "Updated Name", "Updated Description");

        assertEquals("Original Name", tempTask.getTaskById(taskId).getName());
        assertEquals("Original Description", tempTask.getTaskById(taskId).getDescription());
    }

    @Test
    @DisplayName("Add task with invalid data throws exception")
    void testAddTaskInvalidData() {
        tempTask = new TaskService();

        assertThrows(IllegalArgumentException.class, () -> {
            tempTask.addUniqueTask(null, "Valid Description");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            tempTask.addUniqueTask("Valid Name", null);
        });

        assertThrows(IllegalArgumentException.class, () -> {
            tempTask.addUniqueTask("ThisNameIsWayTooLongToBeValid", "Valid Description");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            tempTask.addUniqueTask("Valid Name", "D".repeat(51));
        });
    }

    @Test
    @DisplayName("Update task with invalid data throws exception")
    void testUpdateTaskInvalidData() {
        tempTask = new TaskService();

        String taskId = tempTask.addUniqueTask("Valid Name", "Valid Description");

        assertThrows(IllegalArgumentException.class, () -> {
            tempTask.updateTasks(taskId, null, "New Description");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            tempTask.updateTasks(taskId, "New Name", "");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            tempTask.updateTasks(taskId, "N".repeat(21), "New Description");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            tempTask.updateTasks(taskId, "New Name", "D".repeat(51));
        });
    }
}
